# Java Console-Based Quiz App

## Description
A simple console-based quiz application built using Java. The app asks multiple-choice questions, collects user responses, and shows the final score.

## How to Run
1. Compile the Java file:
   ```bash
   javac QuizApp.java
   ```

2. Run the program:
   ```bash
   java QuizApp
   ```

## Key Concepts Used
- Control flow (if-else, loops)
- Java Collections (ArrayList)
- Scanner for user input

## Author
Intern - Java Developer Task 8